#--- Part II: implement stacks using mutable lists; implement queues using two stacks

#-- Kyle Nealy
#-- knealy@indiana.edu

from a3_1 import * 

class Stack :
    """
    The stack interface is described in our book:
    "http://interactivepython.org/runestone/static/pythonds/BasicDS/TheStackAbstractDataType.html"

    >>> s = Stack()
    >>> s.isEmpty()
    True
    >>> s.push(4)
    >>> s.push('dog')
    >>> s.peek()
    'dog'
    >>> s.push(True)
    >>> s.size()
    3
    >>> s.isEmpty()
    False
    >>> s.push(8.4)
    >>> s.pop()
    8.4
    >>> s.pop()
    True
    >>> s.size()
    2
    """

    def __init__ (self) :
        self.stack = MutableList()

    def isEmpty (self) :
        return self.stack.isEmpty()

    def size (self) :
        return self.stack.size()

    def push (self, v) :
        self.stack.append(v)

    def pop (self):
        return self.stack.pop()

    def peek (self) :
        return self.stack.front.drop(self.size()-1).head
    
    def __str__ (self) :
        return str(self.stack)


class Queue :
    """
    The queue interface is described in our book:
    "http://interactivepython.org/runestone/static/pythonds/BasicDS/TheQueueAbstractDataType.html"

    >>> q = Queue()
    >>> q.isEmpty()
    True
    >>> q.enqueue(4)
    >>> q.enqueue('dog')
    >>> q.enqueue(True)
    >>> q.size()
    3
    >>> q.isEmpty()
    False
    >>> q.dequeue()
    4
    >>> q.enqueue(8.4)
    >>> q.dequeue()
    'dog'
    >>> q.dequeue()
    True
    >>> q.dequeue()
    8.4
    >>> q.size()
    0
    """
    def __init__ (self) :
        self.front = Stack()
        self.back = Stack()
    
    def isEmpty (self) :
        return self.front.stack.isEmpty()

    def size (self) :
        return self.front.stack.size()

    def enqueue (self, v) :
        self.front.stack.add(v) 

    def dequeue (self) :
        return self.front.stack.pop()

    def __str__ (self) :
        return str(self.front.stack)

if __name__ == "__main__" :
  import doctest
  doctest.testmod()
