#--- Part III: implement cyclic lists; implement the Josephus problem

#-- Kyle Nealy
#-- knealy@indiana.edu

from lec4 import *

class CyclicList :

  """Similar in spirit to the class MutableList but the list MAY contain cycles.
  >>> xs = CyclicList()
  >>> xs.add(1)
  >>> xs.add(2)
  >>> xs.add(3)
  >>> xs.add(4)
  >>> xs.add(5)
  >>> xs.take(10)
  [5, 4, 3, 2, 1]
  >>> xs.take(2)
  [5, 4]
  >>> xs.hasLoop()
  False
  >>> xs.setTail(5,1)
  >>> xs.take(12)
  [5, 4, 3, 2, 1, 5, 4, 3, 2, 1, 5, 4]
  >>> xs.hasLoop()
  True
  >>> xs.setTail(5,2)
  >>> xs.take(12)
  [5, 4, 3, 2, 1, 4, 3, 2, 1, 4, 3, 2]
  >>> xs.hasLoop()
  True
  """

  def __init__(self) :
    self.front = EmptyList()

  def __str__(self):
    return str(self.front)

  def add (self,v) :
    self.front = self.front.add(v)

  def next (self) :
    """Adjusts the front pointer to point to the tail."""
    if (not self.isEmpty()):
      self.front = self.front.tail

  def singleton (self) :
    """Returns True or False depending on whether the list has exactly one element
    or not.
    >>> xs = CyclicList()
    >>> xs.add(5)
    >>> xs.singleton()
    True
    >>> xs = CyclicList()
    >>> xs.add(5)
    >>> xs.setTail(1,1)
    >>> xs.singleton()
    True
    >>> xs = CyclicList()
    >>> xs.singleton()
    False
    >>> xs = CyclicList()
    >>> xs.add(5)
    >>> xs.add(6)
    >>> xs.singleton()
    False
    >>> xs = CyclicList()
    >>> xs.add(5)
    >>> xs.add(6)
    >>> xs.setTail(2,1)
    >>> xs.singleton()
    False
    """
    return (self.front.tail.isEmpty() and self.front.size()==1)

  def deleteNext (self) :
    """Deletes the next node. Returns the contents of the deleted node.
    >>> xs = CyclicList()
    >>> xs.add(1)
    >>> xs.add(2)
    >>> xs.add(3)
    >>> xs.add(4)
    >>> xs.take(10)
    [4, 3, 2, 1]
    >>> xs.next()
    >>> xs.take(10)
    [3, 2, 1]
    >>> xs.deleteNext()
    2
    >>> xs.take(10)
    [3, 1]
    """
    dat = self.front.drop(1).head
    self.front.tail = self.front.tail.tail
    return dat
   
  def take (self,i) :
    """Traverses the current object and collects the elements in a Python list. If the
    current object does not have a cycle and has fewer than 'i' elements, the result
    is just the elements in the current list. If the current object contains more than
    'i' elements or is cyclic, only the first 'i' elements are collected."""
    tmp = list()
    if self.front.size()<i and (not self.hasLoop()):
      tmp.append(self.front)
    else:
      tmp.append(self[:i])
    return tmp

  def setTail (self,j,i) :
    """Set the tail pointer of the 'j'th node (counting from 1) to point to
    the 'i'th node (again counting from 1). If i <= j, this will create a
    cycle in the list."""
    jNode = self.front.drop(j)
    iNode = self.front.drop(i)
    jNode.tail = iNode

  def hasLoop (self) :
    """Detects if the current list has a loop."""
    pass
    
  def isEmpty (self) :
    return self.front.isEmpty()

#---

class Josephus :

  """The Josephus Problem is a classic problem that involves cyclic lists.
  See a nice description at "http://mathworld.wolfram.com/JosephusProblem.html".
  """

  def __init__ (self,n,k) :
    """The parameter 'n' is the number of people; they are numbered 1 to n;
    the parameter 'k' is the count used at each step where k-1 people are skipped
    and the k'th person is executed.
    >>> Josephus(5,2).people.take(12)
    [1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2]
    """
    pass

  def skip(self,i) :
    """Moves the pointer to 'people' by 'i' steps.
    >>> j = Josephus(5,2)
    >>> j.people.take(12)
    [1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2]
    >>> j.skip(3)
    >>> j.people.take(12)
    [4, 5, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5]
    >>> j.skip(3)
    >>> j.people.take(12)
    [2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2, 3]
    >>> j.skip(3)
    >>> j.people.take(12)
    [5, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1]
    """
    pass

  def simulate(self,i) :
    """Start the simulation from person number 'i'
    >>> j = Josephus(10,2)
    >>> j.simulate(3)
    8
    >>> j = Josephus(20,7)
    >>> j.simulate(1)
    4
    >>> j = Josephus(41,3)
    >>> j.simulate(41)
    31
    """
    pass

#-----------------------------------------------------------------------------

if __name__ == "__main__" :
  import doctest
  doctest.testmod()

